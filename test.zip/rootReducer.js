import { combineReducers } from 'redux';
import music from './reducers/music';

export default combineReducers({
  music
});
